@extends('layouts.app')
@section('title','Edit Category')
@section('content')
<div class="main-panel">
    <div class="container">
       <div class="page-inner">
          <div class="row">
            <div class="col-md-2">
 
            </div>
             <div class="col-md-8">
                <div class="card">
                   <div class="card-body">
                    {!! Form::model($category,['route'=>['category.update',$category->id],'class'=>'form-horizontal','method'=>'PUT']) !!}
                    
                    @include('category.form')  
           
                     {!! Form::close() !!}  
                   </div>
                </div>
             </div>
             <div class="col-md-2">
 
             </div>
          </div>
       </div>
    </div>
 </div>
 </div>
@endsection